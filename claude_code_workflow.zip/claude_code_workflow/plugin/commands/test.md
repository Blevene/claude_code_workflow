---
description: Test command to verify slash commands are working
---

Say "Hello! Slash commands are working correctly!" and list what project directory you see.
